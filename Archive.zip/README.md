This is a sample app to demonstrate the [Heroku buildpack for
Shiny](https://github.com/btubbs/heroku-buildpack-shiny).  More details are
available there.
